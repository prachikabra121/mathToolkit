# Math Toolkit

A simple math toolkit for basic operations.

## Installation

To install the package, use:

```bash
pip install math_toolkit
from math_toolkit.operations import add, subtract, multiply, divide

print(add(10, 5))        # Output: 15
print(subtract(10, 5))   # Output: 5
print(multiply(10, 5))   # Output: 50
print(divide(10, 5))     # Output: 2.0
